/*
  +----------------------------------------------------------------------------+
  | (C) ADDI-DATA GmbH         Dieselstrasse 3       D-77833 Ottersweier       |
  +----------------------------------------------------------------------------+
  | Tel : +49 (0) 7223/9493-0       | email    : info@addi-data.com            |
  | Fax : +49 (0) 7223/9493-92      | Internet : http://www.addi-data.com      |
  +---------------------------------+------------------------------------------+
  | Project     : APCI-1710         |     Compiler   : GCC                     |
  | Module name : apci1710_module.c |     Version    : 2.96                    |
  +-------------------------------+--------------------------------------------+
  | Author      : J. Krauth       |     Date       : 28.06.2004                |
  +-------------------------------+--------------------------------------------+
  | Description : Samples for the APCI-1710.                                   |                                                              
  |                                                                            |
  +----------------------------------------------------------------------------+
  |                             UPDATES                                        |
  +----------+-----------+-----------------------------------------------------+
  |   Date   |   Author  |          Description of updates                     |
  +----------+-----------+-----------------------------------------------------+
  | 28.06.04 | J. Krauth | - Creation.                                         | 
  +----------+-----------+-----------------------------------------------------+
  | 05.08.04 | J. Krauth | - Append ETM sample4.                               | 
  |          | J. Krauth | - Remove double.                                    |   
  +----------+-----------+-----------------------------------------------------+  
*/


#ifndef MODULE
   #define MODULE
#endif 
   
#ifndef __KERNEL__
   #define __KERNEL__
#endif  

/*
  +----------------------------------------------------------------------------+
  |                               Included files                               |
  +----------------------------------------------------------------------------+
*/

#include "apci1710.h"
#include <linux/module.h>
#include <linux/delay.h>

//********************************* Module information ********************************
MODULE_LICENSE("GPL");
MODULE_AUTHOR("ADDI-DATA GmbH <info@addi-data.com>");
MODULE_DESCRIPTION("MSX-Box APCI-1710 Module");
//*************************************************************************************



void	v_Sample1	(void)
{
  unsigned char  b_BoardHandle = 0;	// APCI-1710 Board handle
  unsigned char  b_ModuleNbr;		// Module number to test
  int 	       i_ReturnValue;		// Return error code
  unsigned long ul_CounterValue = 0;	// Counter value


  /****************************/
  /* Print sample information */
  /****************************/

  printk ("\n\n");
  printk ("\n+---------------------------------------------------+");
  printk ("\n| APCI-1710 incremental counter:                    |");
  printk ("\n| Initialise the incremental counter                |");
  printk ("\n| 1*32-Bit counter / simple mode / hysteresis ON.   |");
  printk ("\n| Read counters.                                    |");
  printk ("\n+---------------------------------------------------+");
  printk ("\n\n");

  /**************************************/
  /* Get module number to test (0 to 3) */
  /**************************************/

  b_ModuleNbr = 1;

  /**************************************/
  /* Initialise the incremental counter */
  /**************************************/

  i_ReturnValue = i_APCI1710_InitCounter (b_BoardHandle,
					  b_ModuleNbr,
					  APCI1710_32BIT_COUNTER,
					  APCI1710_SIMPLE_MODE,
					  APCI1710_HYSTERESIS_ON,
					  APCI1710_SIMPLE_MODE,
					  APCI1710_HYSTERESIS_ON);

  /*************************/
  /* Test the return value */
  /*************************/

  switch (i_ReturnValue)
    {
    case 0:
      printk ("\ni_APCI1710_InitCounter OK");

      i_ReturnValue = i_APCI1710_Write32BitCounterValue (b_BoardHandle,
							 b_ModuleNbr,
							 0);	   	   
      switch (i_ReturnValue)
	{
	case 0:
	  printk ("\ni_APCI1710_Write32BitCounterValue OK");	
	  break;                           
                      									     
	case -1:
	  printk ("\ni_APCI1710_Write32BitCounterValue error");
	  printk ("\nError = %d. The handle parameter of the board is wrong", i_ReturnValue);
	  break;
	
	case -2:
	  printk ("\ni_APCI1710_Write32BitCounterValue error");
	  printk ("\nError = %d. The module is not a counter module", i_ReturnValue);
	  break;
	
	case -3:
	  printk ("\ni_APCI1710_Write32BitCounterValue error");
	  printk ("\nError = %d. Counter not initialized", i_ReturnValue);
	  break;
	
	default:
	  printk ("\ni_APCI1710_Write32BitCounterValue error");
	  printk ("\nError = %d", i_ReturnValue);
	  break;
	} // switch (i_ReturnValue)
		      
      for (;;)
	{

	  /********************/
	  /* Read the counter */
	  /********************/
	  i_ReturnValue = i_APCI1710_Read32BitCounterValue (b_BoardHandle,
							    b_ModuleNbr,
							    &ul_CounterValue);
	  switch (i_ReturnValue)
	    {
	    case 0:
	      printk ("\nCounter value from module %d = %5lu", b_ModuleNbr, ul_CounterValue);	
	      break;
                                                 									     
	    case -1:
	      printk ("\ni_APCI1710_Read32BitCounterValue error");
	      printk ("\nError = %d. The handle parameter of the board is wrong", i_ReturnValue);
	      break;
	
	    case -2:
	      printk ("\ni_APCI1710_Read32BitCounterValue error");
	      printk ("\nError = %d. The module is not a counter module", i_ReturnValue);
	      break;
	
	    case -3:
	      printk ("\ni_APCI1710_Read32BitCounterValue error");
	      printk ("\nError = %d. No counter module", i_ReturnValue);
	      break;
	
	    case -4:
	      printk ("\ni_APCI1710_Read32BitCounterValue error");
	      printk ("\nError = %d. Counter not initialized", i_ReturnValue);
	      break;
	
	    default:
	      printk ("\ni_APCI1710_Read32BitCounterValue error");
	      printk ("\nError = %d", i_ReturnValue);
	      break;
	    } // switch (i_ReturnValue)								     

	} // for (;;)
      break;

    case -1:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The handle parameter of the board is wrong", i_ReturnValue);
      break;

    case -2:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The module is not a counter module", i_ReturnValue);
      break;

    case -3:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The selected counter range is wrong", i_ReturnValue);
      break;

    case -4:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The selected first counter operating mode is wrong", i_ReturnValue);
      break;

    case -5:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The selected first counter operating option is wrong", i_ReturnValue);
      break;

    case -6:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The selected second counter operating mode is wrong", i_ReturnValue);
      break;

    case -7:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The selected second counter operating option is wrong", i_ReturnValue);
      break;

    default:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d", i_ReturnValue);
      break;
    } // switch (i_ReturnValue)
}


void v_Sample2 (void)
{
  unsigned char  b_BoardHandle = 0;	// APCI-1710 Board handle
  unsigned char  b_ClockSelection;	// Clock selection
  unsigned char  b_SelectedPWM;		// PWM counter number to test
  unsigned char  b_ModuleNbr;		// Module number to test
  unsigned char  b_TimingUnit;          // Timing unity selection
  unsigned char  b_PWMOutputStatus;	// Output level
  unsigned char  b_ExternGateStatus;	// Extern gate status
  unsigned long ul_LowTiming;           // Low timing
  unsigned long ul_HighTiming;          // High timing
  unsigned long ul_RealLowTiming;	// Real low timing
  unsigned long ul_RealHighTiming;	// Real high timing
  int 	       i_ReturnValue;		// Return error code

  /****************************/
  /* Print sample information */
  /****************************/

  printk ("\n\n");
  printk ("\n+---------------------------------------------------+");
  printk ("\n| APCI-1710 PWM counter:                            |");
  printk ("\n| Read 1 PWM status.                                |");
  printk ("\n| PWM initialisation :                              |");
  printk ("\n|   - The period start witch a low level            |");
  printk ("\n|   - The PWM is stopped directly after             |");
  printk ("\n|     the 'i_APCI1710_DisablePWM' and break         |");
  printk ("\n|     the last period                               |");
  printk ("\n|   - The output signal keep the level              |");
  printk ("\n|     after the 'i_APCI1710_DisablePWM'             |");
  printk ("\n|   - Extern gate disable                           |");
  printk ("\n|   - Interrupt disable                             |");
  printk ("\n+---------------------------------------------------+");
  printk ("\n\n");
	

  /*************************************/
  /* Get module number to test (0 - 3) */
  /*************************************/
  b_ModuleNbr = 0;

  /**************************************/
  /* Get module number to test (0 or 1) */
  /**************************************/
  b_SelectedPWM = 0;

  /***********************/
  /* Get Clock selection */
  /***********************/
  //b_ClockSelection = APCI1710_30MHZ;
  //b_ClockSelection = APCI1710_33MHZ;
  b_ClockSelection = APCI1710_40MHZ;
	   
  /*
    +------------------+--------------+-------------------+-------------------+
    | Clock Selecetion | b_TimingUnit | ul_TimingInterval | ul_TimingInterval | 
    |                  |              | minimal value     | maximal value     | 
    +------------------+--------------+-------------------+-------------------+
    |                  | ns (0)       | 266               | 4294967295        |
    |                  +--------------+-------------------+-------------------+
    |                  | �s (1)       | 1                 | 571230650         |
    |                  +--------------+-------------------+-------------------+
    | APCI1710_30MHZ   | ms (2)       | 1                 | 571230            |
    |                  +--------------+-------------------+-------------------+
    |                  | s  (3)       | 1                 | 571               |
    |                  +--------------+-------------------+-------------------+
    |                  | mn (4)       | 1                 | 9                 |
    +------------------+--------------+-------------------+-------------------+
    |                  | ns (0)       | 242               | 4294967295        |
    |                  +--------------+-------------------+-------------------+
    |                  | �s (1)       | 1                 | 519691043         |
    |                  +--------------+-------------------+-------------------+
    | APCI1710_33MHZ   | ms (2)       | 1                 | 519691            |
    |                  +--------------+-------------------+-------------------+
    |                  | s  (3)       | 1                 | 520               |
    |                  +--------------+-------------------+-------------------+
    |                  | mn (4)       | 1                 | 8                 |
    +------------------+--------------+-------------------+-------------------+
    |                  | ns (0)       | 200               | 4294967295        |
    |                  +--------------+-------------------+-------------------+
    |                  | �s (1)       | 1                 | 429496729         |
    |                  +--------------+-------------------+-------------------+
    | APCI1710_40MHZ   | ms (2)       | 1                 | 429496            |
    |                  +--------------+-------------------+-------------------+
    |                  | s  (3)       | 1                 | 429               |
    |                  +--------------+-------------------+-------------------+
    |                  | mn (4)       | 1                 | 7                 |
    +------------------+--------------+-------------------+-------------------+*/	   

  /********************/
  /* Get timing unity */
  /* 0 for ns.        */
  /* 1 for �s.        */
  /* 2 for ms.        */
  /* 3 for s.         */
  /* 4 for mn.        */
  /********************/
  b_TimingUnit = 2;

  /************************/
  /* Get low timing value */
  /************************/
  ul_LowTiming = 1;

  /*************************/
  /* Get High timing value */
  /*************************/
  ul_HighTiming = 1;

  /**********************/
  /* Initialise the PWM */
  /**********************/

  i_ReturnValue = i_APCI1710_InitPWM      (b_BoardHandle,
					   b_ModuleNbr,
					   b_SelectedPWM,
					   b_ClockSelection,
					   b_TimingUnit,
					   ul_LowTiming,
					   ul_HighTiming,
					   &ul_RealLowTiming,
					   &ul_RealHighTiming);	   
						    			   
  /*************************/
  /* Test the return value */
  /*************************/

  switch (i_ReturnValue)
    {
    case 0 :
      printk ("\ni_APCI1710_InitPWM OK");

      /*************************************************/
      /* Enable the PWM                                */
      /*************************************************/
      /*  - The period start witch a low level         */
      /*  - The PWM is stopped directly after          */
      /*	 the "i_APCI1710_DisablePWM" and break */
      /*	 the last period                       */
      /*  - The output signal keep the level           */
      /*	 after the "i_APCI1710_DisablePWM"     */
      /*  - Extern gate disable                        */
      /*  - Interrupt disable                          */
      /*************************************************/

      i_ReturnValue = i_APCI1710_EnablePWM (b_BoardHandle,
					    b_ModuleNbr,
					    b_SelectedPWM,
					    0,
					    0,
					    0,
					    0,
					    APCI1710_DISABLE);

      /*************************/
      /* Test the return value */
      /*************************/

      switch (i_ReturnValue)
	{
	case 0:
	  printk ("\n");
	  for (;;)
	    {
	      /**********************/
	      /* Get the PWM status */
	      /**********************/

	      i_ReturnValue = i_APCI1710_GetPWMStatus (b_BoardHandle,
						       b_ModuleNbr,
						       b_SelectedPWM,
						       &b_PWMOutputStatus,
						       &b_ExternGateStatus);

	      /*************************/
	      /* Test the return value */
	      /*************************/

	      switch (i_ReturnValue)
		{
		case 0:
		  if (b_PWMOutputStatus)
		    {
		      printk ("\rThe output signal is high. Extern gate level = %d", b_ExternGateStatus);
		    }
		  else
		    {
		      printk ("\rThe output signal is low . Extern gate level = %d ", b_ExternGateStatus);
		    }
		  break;

		case -1:
		  printk ("\ni_APCI1710_GetPWMStatus error");
		  printk ("\nError = %d. The handle parameter of the board is wrong.", i_ReturnValue);
		  break;

		case -2:
		  printk ("\ni_APCI1710_GetPWMStatus error");
		  printk ("\nError = %d. Module selection wrong.", i_ReturnValue);
		  break;

		case -3:
		  printk ("\ni_APCI1710_GetPWMStatus error");
		  printk ("\nError = %d. The module is not a PWM module.", i_ReturnValue);
		  break;

		case -4:
		  printk ("\ni_APCI1710_GetPWMStatus error");
		  printk ("\nError = %d. PWM selection is wrong.", i_ReturnValue);
		  break;

		case -5:
		  printk ("\ni_APCI1710_GetPWMStatus error");
		  printk ("\nError = %d. PWM not initialised.", i_ReturnValue);
		  break;

		case -6:
		  printk ("\ni_APCI1710_GetPWMStatus error");
		  printk ("\nError = %d. PWM not enabled.", i_ReturnValue);
		  break;

		default:
		  printk ("\ni_APCI1710_GetPWMStatus error");
		  printk ("\nError = %d.", i_ReturnValue);
		  break;
		}

	    } // for (;;)

	  /*******************/
	  /* Disable the PWM */
	  /*******************/

	  i_ReturnValue = i_APCI1710_DisablePWM (b_BoardHandle,
						 b_ModuleNbr,
						 b_SelectedPWM);

	  /*************************/
	  /* Test the return value */
	  /*************************/

	  switch (i_ReturnValue)
	    {
	    case 0:
	      printk ("\n\ni_APCI1710_DisablePWM OK");
	      break;

	    case -1:
	      printk ("\ni_APCI1710_DisablePWM error");
	      printk ("\nError = %d. The handle parameter of the board is wrong.", i_ReturnValue);
	      break;

	    case -2:
	      printk ("\ni_APCI1710_DisablePWM error");
	      printk ("\nError = %d. Module selection wrong.", i_ReturnValue);
	      break;

	    case -3:
	      printk ("\ni_APCI1710_DisablePWM error");
	      printk ("\nError = %d. The module is not a PWM module.", i_ReturnValue);
	      break;

	    case -4:
	      printk ("\ni_APCI1710_DisablePWM error");
	      printk ("\nError = %d. PWM selection is wrong.", i_ReturnValue);
	      break;

	    case -5:
	      printk ("\ni_APCI1710_DisablePWM error");
	      printk ("\nError = %d. PWM not initialised.", i_ReturnValue);
	      break;

	    case -6:
	      printk ("\ni_APCI1710_DisablePWM error");
	      printk ("\nError = %d. PWM not enabled.", i_ReturnValue);
	      break;

	    default:
	      printk ("\ni_APCI1710_DisablePWM error");
	      printk ("\nError = %d.", i_ReturnValue);
	      break;
	    }
	  break;

	case -1:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. The handle parameter of the board is wrong.", i_ReturnValue);
	  break;

	case -2:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. Module selection wrong.", i_ReturnValue);
	  break;

	case -3:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. The module is not a PWM module.", i_ReturnValue);
	  break;

	case -4:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. PWM selection is wrong.", i_ReturnValue);
	  break;

	case -5:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. PWM not initialised.", i_ReturnValue);
	  break;

	case -6:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. PWM start level selection is wrong.", i_ReturnValue);
	  break;

	case -7:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. PWM stop mode selection is wrong.", i_ReturnValue);
	  break;

	case -8:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. PWM stop level selection is wrong.", i_ReturnValue);
	  break;

	case -9:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. Extern gate signal selection is wrong.", i_ReturnValue);
	  break;

	case -10:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. Interrupt parameter is wrong.", i_ReturnValue);
	  break;

	case -11:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d. Interrupt function not initialised.", i_ReturnValue);
	  break;

	default:
	  printk ("\ni_APCI1710_EnablePWM error");
	  printk ("\nError = %d.", i_ReturnValue);
	  break;
	}
      break;

    case -1:
      printk ("\ni_APCI1710_InitPWM error");
      printk ("\nError = %d. The handle parameter of the board is wrong.", i_ReturnValue);
      break;

    case -2:
      printk ("\ni_APCI1710_InitPWM error");
      printk ("\nError = %d. Module selection wrong.", i_ReturnValue);
      break;

    case -3:
      printk ("\ni_APCI1710_InitPWM error");
      printk ("\nError = %d. The module is not a PWM module.", i_ReturnValue);
      break;

    case -4:
      printk ("\ni_APCI1710_InitPWM error");
      printk ("\nError = %d. PWM selection is wrong.", i_ReturnValue);
      break;

    case -5:
      printk ("\ni_APCI1710_InitPWM error");
      printk ("\nError = %d. The selected input clock is wrong.", i_ReturnValue);
      break;

    case -6:
      printk ("\ni_APCI1710_InitPWM error");
      printk ("\nError = %d. Timing Unit selection is wrong.", i_ReturnValue);
      break;

    case -7:
      printk ("\ni_APCI1710_InitPWM error");
      printk ("\nError = %d. Low base timing selection is wrong.", i_ReturnValue);
      break;

    case -8:
      printk ("\ni_APCI1710_InitPWM error");
      printk ("\nError = %d. High base timing selection is wrong.", i_ReturnValue);
      break;

    case -9:
      printk ("\ni_APCI1710_InitPWM error");
      printk ("\nError = %d. You can not used the 40MHz clock selection with this board.", i_ReturnValue);
      break;

    default:
      printk ("\ni_APCI1710_InitPWM error");
      printk ("\nError = %d.", i_ReturnValue);
      break;
    }
}

void	v_Sample3	(void)
{
  unsigned char b_BoardHandle = 0;	// APCI-1710 Board handle
  unsigned char b_ModuleNbr;		// Module number to test
  int 	      i_ReturnValue;		// Return error code
  unsigned int ui_FirstCounterValue;      // First 16-Bit counter value
  unsigned int ui_SecondCounterValue;     // Second 16-Bit counter value


  /****************************/
  /* Print sample information */
  /****************************/

  printk ("\n\n");
  printk ("\n+---------------------------------------------------+");
  printk ("\n| APCI-1710 incremental counter:                    |");
  printk ("\n| Initialise the incremental counter                |");
  printk ("\n| 2*16-Bit counter / simple mode / hysteresis on.   |");
  printk ("\n| Read counters.                                    |");
  printk ("\n+---------------------------------------------------+");
  printk ("\n\n");

  /*************************************/
  /* Get module number to test (0 - 3) */
  /*************************************/
  b_ModuleNbr = 1;

  /**************************************/
  /* Initialise the incremental counter */
  /**************************************/

  i_ReturnValue = i_APCI1710_InitCounter (b_BoardHandle,
					  b_ModuleNbr,
					  APCI1710_16BIT_COUNTER,
					  APCI1710_SIMPLE_MODE,
					  APCI1710_HYSTERESIS_ON,
					  APCI1710_SIMPLE_MODE,
					  APCI1710_HYSTERESIS_ON);
						   
  /*************************/
  /* Test the return value */
  /*************************/

  switch (i_ReturnValue)
    {
    case 0:
      printk ("\ni_APCI1710_InitCounter OK");
		   
      i_ReturnValue = i_APCI1710_Write16BitCounterValue (b_BoardHandle,
							 b_ModuleNbr,
							 0, // Counter
							 0);// Value	   	   
      switch (i_ReturnValue)
	{
	case 0:
	  printk ("\ni_APCI1710_Write16BitCounterValue OK");	
                      									     
	case -1:
	  printk ("\ni_APCI1710_Write16BitCounterValue error");
	  printk ("\nError = %d. The handle parameter of the board is wrong", i_ReturnValue);
	  break;
	
	case -2:
	  printk ("\ni_APCI1710_Write16BitCounterValue error");
	  printk ("\nError = %d. The module is not a counter module", i_ReturnValue);
	  break;
	
	case -3:
	  printk ("\ni_APCI1710_Write16BitCounterValue error");
	  printk ("\nError = %d. Counter not initialized", i_ReturnValue);
	  break;
			   
	case -4:
	  printk ("\ni_APCI1710_Write16BitCounterValue error");
	  printk ("\nError = %d. Counter selection error", i_ReturnValue);
	  break;			   
	
	default:
	  printk ("\ni_APCI1710_Write16BitCounterValue error");
	  printk ("\nError = %d", i_ReturnValue);
	  break;
	} // switch (i_ReturnValue)
		      
      i_ReturnValue = i_APCI1710_Write16BitCounterValue (b_BoardHandle,
							 b_ModuleNbr,
							 1, // Counter
							 0);// Value	   	   
      switch (i_ReturnValue)
	{
	case 0:
	  printk ("\ni_APCI1710_Write16BitCounterValue OK");	
                      									     
	case -1:
	  printk ("\ni_APCI1710_Write16BitCounterValue error");
	  printk ("\nError = %d. The handle parameter of the board is wrong", i_ReturnValue);
	  break;
	
	case -2:
	  printk ("\ni_APCI1710_Write16BitCounterValue error");
	  printk ("\nError = %d. The module is not a counter module", i_ReturnValue);
	  break;
	
	case -3:
	  printk ("\ni_APCI1710_Write16BitCounterValue error");
	  printk ("\nError = %d. Counter not initialized", i_ReturnValue);
	  break;
			   
	case -4:
	  printk ("\ni_APCI1710_Write16BitCounterValue error");
	  printk ("\nError = %d. Counter selection error", i_ReturnValue);
	  break;			   
	
	default:
	  printk ("\ni_APCI1710_Write16BitCounterValue error");
	  printk ("\nError = %d", i_ReturnValue);
	  break;
	} // switch (i_ReturnValue)		      		   

      /***************************************************/
      /* Read the first 16-Bit and second 16-Bit counter */
      /***************************************************/

      for (;;)
	{
	  /**************************/
	  /* Read the first counter */
	  /**************************/

	  i_ReturnValue = i_APCI1710_Read16BitCounterValue (b_BoardHandle,
							    b_ModuleNbr,
							    0,
							    &ui_FirstCounterValue);


	  /*************************/
	  /* Test the return value */
	  /*************************/

	  switch (i_ReturnValue)
	    {
	    case 0:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the first counter OK");
	      break;

	    case -1:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the first counter error");
	      printk ("\nError = %d. The handle parameter of the board is wrong", i_ReturnValue);
	      break;

	    case -2:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the first counter error");
	      printk ("\nError = %d. No counter module found", i_ReturnValue);
	      break;

	    case -3:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the first counter error");
	      printk ("\nError = %d. Counter not initialised", i_ReturnValue);
	      break;

	    case -4:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the first counter error");
	      printk ("\nError = %d. The selected 16-Bit counter parameter is wrong", i_ReturnValue);
	      break;

	    default:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the first counter error");
	      printk ("\nError = %d.", i_ReturnValue);
	      break;
	    } // switch (i_ReturnValue)


	  /***************************/
	  /* Read the second counter */
	  /***************************/

	  i_ReturnValue = i_APCI1710_Read16BitCounterValue (b_BoardHandle,
							    b_ModuleNbr,
							    1,
							    &ui_SecondCounterValue);


	  /*************************/
	  /* Test the return value */
	  /*************************/

	  switch (i_ReturnValue)
	    {
	    case 0:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the second counter OK");
	      break;

	    case -1:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the second counter error");
	      printk ("\nError = %d. The handle parameter of the board is wrong", i_ReturnValue);
	      break;

	    case -2:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the second counter error");
	      printk ("\nError = %d. No counter module found", i_ReturnValue);
	      break;

	    case -3:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the second counter error");
	      printk ("\nError = %d. Counter not initialised", i_ReturnValue);
	      break;

	    case -4:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the second counter error");
	      printk ("\nError = %d. The selected 16-Bit counter parameter is wrong", i_ReturnValue);
	      break;

	    default:
	      printk ("\ni_APCI1710_Read16BitCounterValue for the second counter error");
	      printk ("\nError = %d.", i_ReturnValue);
	      break;
	    } // switch (i_ReturnValue)


	  /*********************************/
	  /* Print the first counter value */
	  /*********************************/

	  printk ("\nFirst counter value from module %d  = %5u", b_ModuleNbr, ui_FirstCounterValue);

	  /**********************************/
	  /* Print the second counter value */
	  /**********************************/

	  printk ("\nSecond counter value from module %d = %5u", b_ModuleNbr, ui_SecondCounterValue);

	} // for (;;)
      break;

    case -1:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The handle parameter of the board is wrong", i_ReturnValue);
      break;

    case -2:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The module is not a counter module", i_ReturnValue);
      break;

    case -3:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The selected counter range is wrong", i_ReturnValue);
      break;

    case -4:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The selected first counter operating mode is wrong", i_ReturnValue);
      break;

    case -5:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The selected first counter operating option is wrong", i_ReturnValue);
      break;

    case -6:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The selected second counter operating mode is wrong", i_ReturnValue);
      break;

    case -7:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d. The selected second counter operating option is wrong", i_ReturnValue);
      break;

    default:
      printk ("\ni_APCI1710_InitCounter error");
      printk ("\nError = %d", i_ReturnValue);
      break;
    } // switch (i_ReturnValue)

}

/*
 * Test ETM functionality without interrupt 
 */
 
void	v_Sample4	(void)
{
	unsigned char  b_BoardHandle = 0;	// APCI-1710 Board handle
	unsigned char  b_ClockSelection;	// Clock selection
	unsigned char  b_SelectedETM;		// ETM counter number to test
	unsigned char  b_ModuleNbr;		// Module number to test
	unsigned char  b_TimeUnit;              // Timing unity selection
	unsigned char  b_ETMtatus;              // ETM status
	unsigned long ul_Time;                  // Base time
	unsigned long ul_RealTime;		// Real timing
	unsigned long ul_ETMValue;		// ETM read value
	int 	       i_ReturnValue;		// Return error code


	/****************************/
	/* Print sample information */
	/****************************/

	printk ("\n\n");
	printk ("\n+---------------------------------------------------+");
	printk ("\n| APCI-1710 ETM SAMPLE03 :                          |");
	printk ("\n| Read 1 ETM value.                                 |");
	printk ("\n| ETM initialisation :                              |");
	printk ("\n|   - Measure the high level time                   |");
	printk ("\n|   - The ETM trigger which a high level            |");
	printk ("\n|   - Continuous mode. Each trigger stop the        |");
	printk ("\n|     measurement a start a new measurement cycle   |");
	printk ("\n|   - The first edge time measurement start after   |");
	printk ("\n|     the next trigger signal                       |");
	printk ("\n+---------------------------------------------------+");
	printk ("\n\n");

        /*
         * Module number 
         */
         
	b_ModuleNbr = 0;

	   /*****************************/
	   /* Get module number to test */
	   /*****************************/

	   b_SelectedETM = 0;

	   /***********************/
	   /* Get Clock selection */
	   /***********************/

	   /*
	    * Get clock selection. 
	    * 30 MHz APCI1710_30MHZ
	    * 33 MHz APCI1710_33MHZ
	    * 40 MHz APCI1710_40MHZ
	    */
	    
	   b_ClockSelection = APCI1710_40MHZ;

	   /********************/
	   /* Get timing unity */
	   /********************/

	   /*
	    * Time unity: 0 for ns.
	    *             1 for �s.
	    *             2 for ms.
	    */	  

	   b_TimeUnit = 0; //ns

	   /************************/
	   /* Get low timing value */
	   /************************/

	   // Selection for ns	      
	      //APCI1710_30MHZ: Time selection (33 to 559240500)
	      //APCI1710_33MHZ: Time selection (30 to 508400454)
	      //APCI1710_40MHZ: Time selection (25 to 419430375)

	   // Selection for �s	      
	      //APCI1710_30MHZ: Time selection (1 to 559240)
	      //APCI1710_33MHZ: Time selection (1 to 508400)
	      //APCI1710_40MHZ: Time selection (1 to 419430)		       

	   // Selection for ms
	      //APCI1710_30MHZ: Time selection (1 to 559)
	      //APCI1710_33MHZ: Time selection (1 to 508)
	      //APCI1710_40MHZ: Time selection (1 to 419)	
	      
	   ul_Time = 1000; // 1 �s because unit is ns the ETM value will be in 
	                   // �s  	      
	      	   
	   /**********************/
	   /* Initialise the ETM */
	   /**********************/

	   i_ReturnValue = i_APCI1710_InitETM      (b_BoardHandle,
						    b_ModuleNbr,
						    b_ClockSelection,
						    b_TimeUnit,
						    ul_Time,
						    &ul_RealTime);

	   /*************************/
	   /* Test the return value */
	   /*************************/

	   switch (i_ReturnValue)
	      {
	      case 0 :
		   printk ("\ni_APCI1710_InitETM OK");

		   /**************************************************/
		   /* Enable the ETM                                 */
		   /**************************************************/
		   /* ETM initialisation :                           */
		   /*  - Measure the high level time                 */
		   /*  - The ETM trigger which a high level          */
		   /*  - Continuous mode. Each trigger stop the      */
		   /*    measurement a start a new measurement cycle */
		   /*  - The first edge time measurement start after */
		   /*    the next trigger signal                     */
		   /*  - Interrupt disable                           */
		   /**************************************************/

		   i_ReturnValue = i_APCI1710_EnableETM (b_BoardHandle,
							 b_ModuleNbr,
							 b_SelectedETM,
							 1,
							 1,
							 1,
							 1,
							 APCI1710_DISABLE);

		   /*************************/
		   /* Test the return value */
		   /*************************/

		   switch (i_ReturnValue)
		      {
		      case 0:
			   printk ("\n");
			      /**************************************************/
			      /* Delay to make measure                          */ 
			      /* this is not necessary                          */
			      /* the i_APCI1710_GetETMProgressStatus function   */
			      /* can be called in a timer function or in a loop */ 
			      /* to get at any time the ETM status.             */
			      /**************************************************/
			      printk ("\nWait 2 seconds to make measure");
			      mdelay (2000); // Wait 2 seconds
			      			      	
			      /**********************/
			      /* Get the ETM status */
			      /**********************/

			      i_ReturnValue = i_APCI1710_GetETMProgressStatus (b_BoardHandle,
									       b_ModuleNbr,
									       b_SelectedETM,
									       &b_ETMtatus);

			      /*************************/
			      /* Test the return value */
			      /*************************/

			      switch (i_ReturnValue)
				 {
				 case 0:
				      switch (b_ETMtatus)
					 {
					 case 0:
					      printk ("\nETM no trigger signal occur");
					      break;

					 case 1:
					      printk ("\nETM a start trigger signal occur");
					      break;

					 case 2:
					      printk ("\nETM a stop trigger signal occur");

					      /**********************/
					      /* Read the ETM value */
					      /**********************/

					      i_ReturnValue = i_APCI1710_ReadETMValue	(b_BoardHandle,
											 b_ModuleNbr,
											 b_SelectedETM,
											 0,
											 &b_ETMtatus,
											 &ul_ETMValue);

					      /*************************/
					      /* Test the return value */
					      /*************************/

					      switch (i_ReturnValue)
						 {
						 case 0:
						      printk ("\nETM value = %lu", ul_ETMValue);
						      break;

						 case -1:
						      printk ("\ni_APCI1710_ReadETMValue error");
						      printk ("\nError = %d. The handle parameter of the board is wrong.", i_ReturnValue);
						      break;

						 case -2:
						      printk ("\ni_APCI1710_ReadETMValue error");
						      printk ("\nError = %d. Module selection wrong.", i_ReturnValue);
						      break;

						 case -3:
						      printk ("\ni_APCI1710_ReadETMValue error");
						      printk ("\nError = %d. The module is not a ETM module.", i_ReturnValue);
						      break;

						 case -4:
						      printk ("\ni_APCI1710_ReadETMValue error");
						      printk ("\nError = %d. ETM selection is wrong.", i_ReturnValue);
						      break;

						 case -5:
						      printk ("\ni_APCI1710_ReadETMValue error");
						      printk ("\nError = %d. ETM not initialised.", i_ReturnValue);
						      break;

						 case -6:
						      printk ("\ni_APCI1710_ReadETMValue error");
						      printk ("\nError = %d. Timeout parameter is wrong.", i_ReturnValue);
						      break;

						 case -7:
						      printk ("\ni_APCI1710_ReadETMValue error");
						      printk ("\nError = %d. Interrupt routine installed", i_ReturnValue);
						      break;

						 default:
						      printk ("\ni_APCI1710_ReadETMValue error");
						      printk ("\nError = %d.", i_ReturnValue);
						      break;
						 }
					      break;

					 case 3:
					      printk ("\nETM a overflow occur");
					      break;
					 }
				      break;

				 case -1:
				      printk ("\ni_APCI1710_GetETMProgressStatus error");
				      printk ("\nError = %d. The handle parameter of the board is wrong.", i_ReturnValue);
				      break;

				 case -2:
				      printk ("\ni_APCI1710_GetETMProgressStatus error");
				      printk ("\nError = %d. Module selection wrong.", i_ReturnValue);
				      break;

				 case -3:
				      printk ("\ni_APCI1710_GetETMProgressStatus error");
				      printk ("\nError = %d. The module is not a ETM module.", i_ReturnValue);
				      break;

				 case -4:
				      printk ("\ni_APCI1710_GetETMProgressStatus error");
				      printk ("\nError = %d. ETM selection is wrong.", i_ReturnValue);
				      break;

				 case -5:
				      printk ("\ni_APCI1710_GetETMProgressStatus error");
				      printk ("\nError = %d. ETM not initialised.", i_ReturnValue);
				      break;

				 default:
				      printk ("\ni_APCI1710_GetETMProgressStatus error");
				      printk ("\nError = %d.", i_ReturnValue);
				      break;
				 }

			   /*******************/
			   /* Disable the ETM */
			   /*******************/

			   i_ReturnValue = i_APCI1710_DisableETM (b_BoardHandle,
								  b_ModuleNbr,
								  b_SelectedETM);

			   /*************************/
			   /* Test the return value */
			   /*************************/

			   switch (i_ReturnValue)
			      {
			      case 0:
				   printk ("\n\ni_APCI1710_DisableETM OK");
				   break;

			      case -1:
				   printk ("\ni_APCI1710_DisableETM error");
				   printk ("\nError = %d. The handle parameter of the board is wrong.", i_ReturnValue);
				   break;

			      case -2:
				   printk ("\ni_APCI1710_DisableETM error");
				   printk ("\nError = %d. Module selection wrong.", i_ReturnValue);
				   break;

			      case -3:
				   printk ("\ni_APCI1710_DisableETM error");
				   printk ("\nError = %d. The module is not a ETM module.", i_ReturnValue);
				   break;

			      case -4:
				   printk ("\ni_APCI1710_DisableETM error");
				   printk ("\nError = %d. ETM selection is wrong.", i_ReturnValue);
				   break;

			      case -5:
				   printk ("\ni_APCI1710_DisableETM error");
				   printk ("\nError = %d. ETM not initialised.", i_ReturnValue);
				   break;

			      default:
				   printk ("\ni_APCI1710_DisableETM error");
				   printk ("\nError = %d.", i_ReturnValue);
				   break;
			      }
			   break;

		      case -1:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. The handle parameter of the board is wrong.", i_ReturnValue);
			   break;

		      case -2:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. Module selection wrong.", i_ReturnValue);
			   break;

		      case -3:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. The module is not a ETM module.", i_ReturnValue);
			   break;

		      case -4:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. ETM selection is wrong.", i_ReturnValue);
			   break;

		      case -5:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. ETM not initialised.", i_ReturnValue);
			   break;

		      case -6:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. Edge level selection is wrong", i_ReturnValue);
			   break;

		      case -7:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. Trigger level selection is wrong", i_ReturnValue);
			   break;

		      case -8:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. Mode selection is wrong", i_ReturnValue);
			   break;

		      case -9:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. First trigger mode selection is wrong", i_ReturnValue);
			   break;

		      case -10:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. Interrupt parameter is wrong", i_ReturnValue);
			   break;

		      case -11:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d. Interrupt function not initialised.", i_ReturnValue);
			   break;

		      default:
			   printk ("\ni_APCI1710_EnableETM error");
			   printk ("\nError = %d.", i_ReturnValue);
			   break;
		      }
		   break;

	      case -1:
		   printk ("\ni_APCI1710_InitETM error");
		   printk ("\nError = %d. The handle parameter of the board is wrong.", i_ReturnValue);
		   break;

	      case -2:
		   printk ("\ni_APCI1710_InitETM error");
		   printk ("\nError = %d. Module selection wrong.", i_ReturnValue);
		   break;

	      case -3:
		   printk ("\ni_APCI1710_InitETM error");
		   printk ("\nError = %d. The module is not a ETM module.", i_ReturnValue);
		   break;

	      case -4:
		   printk ("\ni_APCI1710_InitETM error");
		   printk ("\nError = %d. ETM selection is wrong.", i_ReturnValue);
		   break;

	      case -5:
		   printk ("\ni_APCI1710_InitETM error");
		   printk ("\nError = %d. The selected input clock is wrong.", i_ReturnValue);
		   break;

	      case -6:
		   printk ("\ni_APCI1710_InitETM error");
		   printk ("\nError = %d. Timing Unit selection is wrong.", i_ReturnValue);
		   break;

	      case -7:
		   printk ("\ni_APCI1710_InitETM error");
		   printk ("\nError = %d. Low base timing selection is wrong.", i_ReturnValue);
		   break;

	      case -8:
		   printk ("\ni_APCI1710_InitETM error");
		   printk ("\nError = %d. High base timing selection is wrong.", i_ReturnValue);
		   break;

	      case -9:
		   printk ("\ni_APCI1710_InitETM error");
		   printk ("\nError = %d. You can not used the 40MHz clock selection with this board.", i_ReturnValue);
		   break;

	      default:
		   printk ("\ni_APCI1710_InitETM error");
		   printk ("\nError = %d.", i_ReturnValue);
		   break;
	      }
}

int init_module(void)
{
    
  if (i_APCI1710_SearchAllAPCI1710 () > 0)
    {
      v_Sample4 ();
    }
  else
    printk ("\nNo board found");       

  return 0;
}


void cleanup_module(void)
{

}
